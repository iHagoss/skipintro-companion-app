# Android Skip Intro Overlay Companion App

This app overlays a "Skip Intro" button on top of Stremio for Android/Firestick.  
It fetches intro skip data from your backend and, with accessibility permissions, will seek past intros in Stremio.

## Features
- Floating overlay button appears when Stremio is running
- Fetches intro skip data from your Koyeb backend
- Accessibility service included to simulate seeking

## How to Build & Use

1. Push these files to your repo.
2. GitHub Actions will build the APK automatically—download from Actions tab.
3. Install APK on your device.
4. Grant Overlay and Accessibility permissions.
5. Start the overlay from the app.
6. Button appears when Stremio is playing a video.
7. Tap button to skip intro (fetches skip time and simulates seek).

## Notes
- StremioInfoDetector and AccessibilityController are best-effort for official Stremio APK. May need tweaks for UI changes.
- Backend server must return correct skip times for episodes/files.

## Support
For improvements, customization, or troubleshooting, open an issue in this repo!